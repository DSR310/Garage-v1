Diagnostic Services and Repairs Ltd — Garage Management V1

Open index.html in a modern browser. On a phone, use the browser's Add to Home Screen option.

Includes: jobs, customers, call/text buttons, parts, labour, 20% VAT, job-to-invoice conversion, invoice numbers, paid/unpaid status, print/save PDF.

V1 stores data locally in the browser on the device. It is a prototype, not yet a cloud-backed production system. Backups, multi-device access, user accounts and secure database storage should be added before relying on it as the sole business record.
